USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Teacher]
           ([Name]
           ,[UserId])
     VALUES
           ('Aidan Wade'
           ,7)
GO

INSERT INTO [dbo].[Teacher]
           ([Name]
           ,[UserId])
     VALUES
           ('William Duncan'
           ,8)
GO
INSERT INTO [dbo].[Teacher]
           ([Name]
           ,[UserId])
     VALUES
           ('Crystal Cole'
           ,9)
GO
INSERT INTO [dbo].[Teacher]
           ([Name]
           ,[UserId])
     VALUES
           ('Diya Horton'
           ,10)
GO
INSERT INTO [dbo].[Teacher]
           ([Name]
           ,[UserId])
     VALUES
           ('Jakobe Rose'
           ,11)
GO
