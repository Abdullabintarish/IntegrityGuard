USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Invigilator]
           ([UserId]
           ,[Name]
           ,[Email])
     VALUES
           (1
           ,'Aliana Lone'
           ,'testinvigilator@test.com')
GO
INSERT INTO [dbo].[Invigilator]
           ([UserId]
           ,[Name]
           ,[Email])
     VALUES
           (2
           ,'Emily Reid'
           ,'testinvigilator1@test.com')
GO
INSERT INTO [dbo].[Invigilator]
           ([UserId]
           ,[Name]
           ,[Email])
     VALUES
           (3
           ,'Clara Evans'
           ,'testinvigilator2@test.com')
GO
INSERT INTO [dbo].[Invigilator]
           ([UserId]
           ,[Name]
           ,[Email])
     VALUES
           (4
           ,'Alexia Riley'
           ,'testinvigilator3@test.com')
GO
INSERT INTO [dbo].[Invigilator]
           ([UserId]
           ,[Name]
           ,[Email])
     VALUES
           (5
           ,'Zion Suarez'
           ,'testinvigilator4@test.com')
GO
INSERT INTO [dbo].[Invigilator]
           ([UserId]
           ,[Name]
           ,[Email])
     VALUES
           (6
           ,'Christian Murphy'
           ,'testinvigilator5@test.com')
GO
