USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Subject]
           ([Name]
           ,[Description])
     VALUES
           ('English'
           ,'This is test subject')
GO

INSERT INTO [dbo].[Subject]
           ([Name]
           ,[Description])
     VALUES
           ('Mathematics'
           ,'This is test subject')
GO
INSERT INTO [dbo].[Subject]
           ([Name]
           ,[Description])
     VALUES
           ('Introduction to ICT'
           ,'This is test subject')
GO
INSERT INTO [dbo].[Subject]
           ([Name]
           ,[Description])
     VALUES
           ('Artificial Intelligence'
           ,'This is test subject')
GO
INSERT INTO [dbo].[Subject]
           ([Name]
           ,[Description])
     VALUES
           ('Physics'
           ,'This is test subject')
GO
