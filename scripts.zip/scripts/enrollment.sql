USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (1
           ,1
           ,1
           ,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (1
           ,2
           ,2
           ,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (1
           ,3
           ,1
           ,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (1
           ,4,
		   4
           ,GetDate())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (1
           ,5
           ,2
           ,GetDate())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (2
           ,1
           ,1
           ,GETDATE())
GO


INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (2
           ,2,
		   2
           ,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (2
           ,3
           ,1
           ,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (2
           ,4,4,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (2
           ,5,2,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (3,1,1,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (3,2,2,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (4,3,1,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (4,1,1,GETDATE())
GO
INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (5,2,2,GETDATE())
GO

INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (5,3,1,GETDATE())
GO
INSERT INTO [dbo].[Enrollment]
           ([StudentId]
           ,[SubjectId]
           ,[TeacherId]
           ,[EnrollDate])
     VALUES
           (5,4,4,GETDATE())
GO