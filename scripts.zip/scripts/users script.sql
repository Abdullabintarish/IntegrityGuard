Invigilaor

USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Aliana Lone'
           ,'testinvigilator@test.com'
           ,'Test123'
           ,'testInvigilator'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'invigilator')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Emily Reid'
           ,'testinvigilator1@test.com'
           ,'Test123'
           ,'testInvigilator1'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'invigilator')
GO
INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Clara Evans'
           ,'testinvigilator2@test.com'
           ,'Test123'
           ,'testInvigilator2'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'invigilator')
GO
INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Alexia Riley'
           ,'testinvigilator3@test.com'
           ,'Test123'
           ,'testInvigilator3'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'invigilator')
GO
INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Zion Suarez'
           ,'testinvigilator4@test.com'
           ,'Test123'
           ,'testInvigilator4'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'invigilator')
GO
INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Christian Murphy'
           ,'testinvigilator5@test.com'
           ,'Test123'
           ,'testInvigilator5'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'invigilator')
GO



Teacher

USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Aidan Wade'
           ,'testteacher1@test.com'
           ,'Test123'
           ,'testTeacher1'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'teacher')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('William Duncan'
           ,'testteacher2@test.com'
           ,'Test123'
           ,'testTeacher2'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'teacher')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Crystal Cole'
           ,'testteacher3@test.com'
           ,'Test123'
           ,'testTeacher3'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'teacher')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Diya Horton'
           ,'testteacher4@test.com'
           ,'Test123'
           ,'testTeacher4'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'teacher')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Jakobe Rose'
           ,'testteacher5@test.com'
           ,'Test123'
           ,'testTeacher5'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'teacher')
GO


Student

USE [IntegrityGuard]
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Nadia Yates'
           ,'testuser1@test.com'
           ,'Test123'
           ,'testUser1'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'student')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Hayden Kaiser'
           ,'testuser2@test.com'
           ,'Test123'
           ,'testUser2'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'student')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Jayden Ryan'
           ,'testuser3@test.com'
           ,'Test123'
           ,'testUser3'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'student')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Jordan Vaughan'
           ,'testuser4@test.com'
           ,'Test123'
           ,'testUser4'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'student')
GO

INSERT INTO [dbo].[Users]
           ([Name]
           ,[Email]
           ,[Password]
           ,[Username]
           ,[PasswordHash]
           ,[Role])
     VALUES
           ('Brielle Lin'
           ,'testuser5@test.com'
           ,'Test123'
           ,'testUser5'
           ,'AQAAAAIAAYagAAAAEMAaHch1zt3roY3tPTSN24daN+SA2cK1LdtiyIlOPAM4qiRxKRvikDooiZkP9DJhRg=='
           ,'student')
GO

