﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;
using WebApp_IntegrityGuard.DataModels;
using WebApp_IntegrityGuard.IntegrityGuard;
using WebApp_IntegrityGuard.Models;

namespace WebApp_IntegrityGuard.Controllers
{
    public class DashboardController : Controller
    {
        private readonly ILogger<DashboardController> _logger;
        private readonly IntegrityGuardContext _dbContext;
        private int UserId;

        public DashboardController(ILogger<DashboardController> logger, IntegrityGuardContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }
        public IActionResult StudentDashboard()
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            ViewData.Add("UserId", UserId);
            ViewData.Add("Exams", GetStudentPageData());
            return View();
        }
        public IActionResult TeacherDashboard()
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            AddExamModel model = new AddExamModel();
            model.TeacherId = _dbContext.Teacher.Where(teacher => teacher.UserId == UserId).Select(t => t.TeacherId).FirstOrDefault().ToString();
            var data = GetTeacherFormData(UserId);

            // Passing the dropdown data to the view using ViewData or by a view model

            ViewData.Add("UserId", UserId);
            ViewData["Subjects"] = new SelectList(data.Subject, "SubjectId", "Name");
            ViewData["Invigilators"] = new SelectList(data.Invigilator, "InvigilatorId", "Name");
            ViewData["UpcomingExams"] = data.Exams;
            return View(model);
        }
        public IActionResult InvigilatorDashboard()
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            ViewData.Add("UserId", UserId);

            var data = GetInvigilatorPageData(UserId);
            ViewData["UpcomingExams"] = data;
            return View();
        }

        //-----------------------------------------------------------------------------------------------
        // STUDENT
        //-----------------------------------------------------------------------------------------------
        public StudentPageData GetStudentPageData()
        {
            var studentDetails = _dbContext.Student.Where(student => student.UserId == UserId).FirstOrDefault();
            var subjectIds = _dbContext.Enrollment.Where(enrollments => enrollments.StudentId == studentDetails.StudentId).Select(e => e.SubjectId).ToList();

            var exams = _dbContext.ExamModel.Where(exams => subjectIds.Contains(exams.SubjectId) && exams.Date.Date >= DateTime.Now.Date).ToList();
            
            var data = new StudentPageData();
            data.Exam = exams;
            return data;
        } 
        public IActionResult CheckExam(ExamModel exam)
        {
            // Parse the date and time strings
            if (DateTime.Now.TimeOfDay > exam.StartTime.TimeOfDay && DateTime.Now.TimeOfDay < exam.EndTime.TimeOfDay)
            {
                ViewData.Add("UserId", UserId);
                HttpContext.Session.SetString("Title", exam.Name+"\'s Exam");
                return RedirectToAction("StudentExam", "Exam", exam);
            }
            else
            {
                // Redirect back to the dashboard with a message that the exam hasn't started
                TempData["Message"] = $"The {exam.Name} exam has not started yet.";

                return RedirectToAction("StudentDashboard");
            }
        }
        public IActionResult TabChange()
        {
            // Log tab change event, update session, etc.
            return Ok(); // Respond with 200 OK to acknowledge receipt
        }
        [HttpPost]
        public async Task<IActionResult> LostFocus([FromBody] MonitoringUpdate body)
        {
            string WarningColor = "";
            
            
            string message = "";
            Console.WriteLine(body.Message);
            var examStatus = new ExamStatusModel
            {
                StudentId=body.StudentId,
                ExamId= body.ExamId,
                Message = body.Message, 
                Time = body.Time,
                TotalTime = body.TotalTime,
                WarningType = body.WarningType
            };

            if (body.WarningType == "TabChange")
            {
                message = "Warning: " + body.Message;
                examStatus.WarningColor = _dbContext.ExamStatusModel.Where(exam => exam.StudentId == body.StudentId && exam.ExamId == body.ExamId && exam.WarningType == "TabChange").Count() > 3 ? "Red" : "Yellow";
            }
            else
            {
                if (body.TotalTime > 0)
                {
                    examStatus.WarningColor = body.TotalTime > 5 ? "Red" : "Yellow";
                    message = "Warning: Face not detected for " + body.TotalTime + " seconds.";
                }
                else
                    message = "Warning: Face not detected";
            }
            _dbContext.ExamStatusModel.Add(examStatus);
            await _dbContext.SaveChangesAsync();

            return Json(new { success = true, response = message });
        }
        public IActionResult TodayExamReport(ExamModel exam)
        {
            // Redirect to the exam view
            HttpContext.Session.SetInt32("UserId", UserId);
            return RedirectToAction("TeacherView", "Exam", exam);
            
        }

        //-----------------------------------------------------------------------------------------------
        // INVIGILATOR
        //-----------------------------------------------------------------------------------------------
        public List<ExamModel> GetInvigilatorPageData(int UserId)
        {
            int invigilatorId = _dbContext.Invigilator.Where(inv => inv.UserId == UserId).Select(invigilatorId => invigilatorId.InvigilatorId).FirstOrDefault();
            var exams = _dbContext.ExamModel.Where(exam => exam.InvigilatorId == invigilatorId).ToList();

            return exams;
        }

        //-----------------------------------------------------------------------------------------------
        // TEACHER
        //-----------------------------------------------------------------------------------------------
        [HttpPost]
        public async Task<IActionResult> AddExam(AddExamModel model)
        {
            if (ModelState.IsValid)
            {
                var subjectDetails = _dbContext.Subject.Where(subject => subject.SubjectId == Int32.Parse(model.SubjectId)).FirstOrDefault();
                int totalEnrollments = _dbContext.Enrollment.Where(enrollment => enrollment.SubjectId == Int32.Parse(model.SubjectId)).Count();
                
                if (subjectDetails != null)
                {
                    ExamModel examModel = new ExamModel()
                    {
                        Name = subjectDetails.Name,
                        Description = "",
                        StartTime = model.StartTime,
                        EndTime = model.EndTime,
                        Duration = (int)(model.EndTime.TimeOfDay - model.StartTime.TimeOfDay).TotalMinutes,
                        TotalStudents = totalEnrollments,
                        Date = model.Date,
                        InvigilatorId = Int32.Parse(model.InvigilatorId),
                        TeacherId = Int32.Parse (model.TeacherId),
                        SubjectId = Int32.Parse(model.SubjectId)
                    };
                    _dbContext.Add(examModel);
                    await _dbContext.SaveChangesAsync();
                }
                
            }

            return RedirectToAction("TeacherDashboard");
        }
        public CreateExamDropDownData GetTeacherFormData(int UserId)
        {

            var teacherId = _dbContext.Teacher.Where(teacher => teacher.UserId == UserId).FirstOrDefault();
            var subjectIds = _dbContext.Enrollment.Where(subject => subject.TeacherId == teacherId.TeacherId).Select(subject => subject.SubjectId).ToList();
            var subjects = _dbContext.Subject.Where(subject => subjectIds.Contains(subject.SubjectId)).ToList();
            var invigilators = _dbContext.Invigilator.ToList();

            var exams = _dbContext.ExamModel.Where(exam => exam.TeacherId == teacherId.TeacherId && exam.Date.Date == DateTime.Now.Date).ToList();
            
            
            CreateExamDropDownData createExamDropDownData = new CreateExamDropDownData();
            createExamDropDownData.Subject = subjects;
            createExamDropDownData.Invigilator = invigilators;
            createExamDropDownData.Exams = exams;
            return createExamDropDownData;
        }
    }
}
