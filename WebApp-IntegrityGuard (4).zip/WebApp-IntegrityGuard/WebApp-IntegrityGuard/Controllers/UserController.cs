﻿using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using WebApp_IntegrityGuard.DataModels;
using WebApp_IntegrityGuard.IntegrityGuard;
using WebApp_IntegrityGuard.Models;

namespace WebApp_IntegrityGuard.Controllers
{
    public class UserController : Controller
    {
        private readonly ILogger<UserController> _logger;
        private readonly IntegrityGuardContext _dbContext;
        private readonly PasswordHasher<UserModel> _passwordHasher;
        public UserController(ILogger<UserController> logger, IntegrityGuardContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
            _passwordHasher = new PasswordHasher<UserModel>();
        }
        public IActionResult Login()
        {
            ViewData.Add("Title", "Login");
            ViewData.Add("TitleDesc", "Protecting academic integrity with cutting-edge technology.");
            return View();
        }

        [HttpPost]
        public IActionResult Login(string username, string password)
        {
            _logger.LogInformation($"Attempting to log in with username: {username}");

            UserModel user = AuthenticateUser(username, password);

            if (user != null)
            {
                
                HttpContext.Session.SetInt32("UserId", user.Id);
                HttpContext.Session.SetString("MessageType", "success");
                HttpContext.Session.SetString("Message", "Welcome "+user.Name+"!\nLogin successfull.");

                CookieOptions options = new CookieOptions();
                options.Expires = DateTime.Now.AddDays(1);
                HttpContext.Response.Cookies.Append("UserId", user.Id.ToString(), options);

                if (user.Role == "student")
                    return RedirectToAction("StudentDashboard", "Dashboard"); 
                else if(user.Role == "teacher")
                    return RedirectToAction("TeacherDashboard", "Dashboard");
                else
                    return RedirectToAction("InvigilatorDashboard", "Dashboard");
            }
            else
            {
                // Return back to the login view with an error message if authentication fails
                ViewBag.ErrorMessage = "Invalid username or password";
                return View();
            }
        }
        
        public IActionResult Register()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> Register(RegisterViewModel model)
        {
            if (ModelState.IsValid)
            {
                // Hash the password
                var user = new UserModel
                {
                    Name = model.Name,
                    Email = model.Email,
                    Username = model.Username,
                    Role = model.Role,
                    Password = model.Password
                };
                user.PasswordHash = _passwordHasher.HashPassword(user, model.Password);

                _dbContext.Add(user);
                await _dbContext.SaveChangesAsync();

                // Redirect to a confirmation page or login page
                return RedirectToAction("Login");
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }


        //Helper Methods
        /*private bool AuthenticateUser(string username, string password)
        {
            if(username == "admin" &&  password == "admin")
            {
                return true;
            }
            return false;
        }*/
        private UserModel AuthenticateUser(string username, string password)
        {
            var user = _dbContext.Users.SingleOrDefault(u => u.Username == username);

            if (user != null)
            {
                // Verify the hashed password
                var result = _passwordHasher.VerifyHashedPassword(user, user.PasswordHash, password);
                if (result == PasswordVerificationResult.Success)
                {
                    return user;
                }
            }

            return null;
        }
    }

}
