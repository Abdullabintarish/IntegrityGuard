﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using System.Data.Entity;
using WebApp_IntegrityGuard.DataModels;
using WebApp_IntegrityGuard.IntegrityGuard;
using WebApp_IntegrityGuard.Models;

namespace WebApp_IntegrityGuard.Controllers
{
    public class ExamController : Controller
    {
        private readonly ILogger<ExamController> _logger;
        private readonly IntegrityGuardContext _dbContext;
        private int UserId;

        public ExamController(ILogger<ExamController> logger, IntegrityGuardContext dbContext)
        {
            _logger = logger;
            _dbContext = dbContext;
        }
        public IActionResult StudentExam(ExamModel exam)
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            ViewData.Add("Title", HttpContext.Session.GetString("Title"));
            ViewData.Add("TitleDesc", "Protecting academic integrity with cutting-edge technology.");

            var studentDetails = _dbContext.Student.Where(student => student.UserId == UserId).FirstOrDefault();

            ViewData.Add("studentDetails", studentDetails);
            ViewData.Add("examDetails", exam);
            ViewData.Add("subject", exam.Name);
            return View();
        }

        public IActionResult TeacherView(ExamModel exam)
        {
           
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            var userType = _dbContext.Users.Where(u => u.Id == UserId).Select(user => user.Role).FirstOrDefault();
            ViewData.Add("Title", exam.Name+"'s Exam");
            ViewData.Add("userRole", userType);
            ViewData.Add("TitleDesc", "Protecting academic integrity with cutting-edge technology.");

            if(DateTime.Now.TimeOfDay > exam.StartTime.TimeOfDay)
            {
                List<ExamDetailsForTeacher> examDetailsForTeachers = new List<ExamDetailsForTeacher>();
                var enrollments = _dbContext.Enrollment.Where(enr => enr.SubjectId == exam.SubjectId).ToList();
                foreach (var enrollment in enrollments)
                {
                    string warningColor = "Green";
                    string warningType = "Good";
                    var examStatus = _dbContext.ExamStatusModel.Where(es => es.ExamId == exam.Id && es.StudentId == enrollment.StudentId).ToList();
                    if (examStatus.Count > 0)
                    {
                        warningColor = examStatus.Where(warning => warning.WarningColor == "Red").Count() > 3 ? "Red" : "Yellow";
                        warningType = warningColor == "Red" ? "Worst" : "Bad";
                    }
                    ExamDetailsForTeacher examDetailsForTeacher = new ExamDetailsForTeacher()
                    {
                        ExamId = exam.Id,
                        StudentId = enrollment.StudentId,
                        Name = _dbContext.Student.Where(s => s.StudentId == enrollment.StudentId).Select(s => s.Name).FirstOrDefault(),
                        WarningColor = warningColor,
                        WarningType = warningType
                    };
                    examDetailsForTeachers.Add(examDetailsForTeacher);
                }

                return View(examDetailsForTeachers);
            }
            else
            {
                return View(null);
            }

            
        }
        [HttpPost]
        public IActionResult GetReportView([FromBody] ExamDetailsForTeacher exam)
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            ViewData.Add("TitleDesc", "Protecting academic integrity with cutting-edge technology.");
            var examDetails = _dbContext.ExamStatusModel.Where(e => e.ExamId == exam.ExamId && e.StudentId == exam.StudentId).ToList();

            TempData["examDetails"] = JsonConvert.SerializeObject(examDetails);

            return Json(new { success = true, message = JsonConvert.SerializeObject(examDetails) });
            //return RedirectToAction(nameof(DetailedReportView));
            //return View(examDetails);
        }

        public IActionResult DetailedReportView(string request)
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            var serializedData = TempData["examDetails"] as string;
            var examDetails = serializedData == null ? new List<ExamStatusModel>() : JsonConvert.DeserializeObject<List<ExamStatusModel>>(serializedData);
            var studentName = _dbContext.Student.Where(stu => examDetails.Count > 0 && examDetails.FirstOrDefault().StudentId == stu.StudentId).Select(stu => stu.Name).FirstOrDefault();
            if (studentName == null)
                studentName = "Student";

            var role = _dbContext.Users.Where(user => user.Id == UserId).Select(user => user.Role).FirstOrDefault();
            var result = _dbContext.Result.Where(result => examDetails.Count > 0 && examDetails.FirstOrDefault().ExamId == result.ExamId && examDetails.FirstOrDefault().StudentId == result.StudentId).FirstOrDefault();
            ViewData.Add("Role", role);
            ViewData.Add("Result", result);
            ViewData.Add("Title", studentName + "'s Detailed Report");
            ViewData.Add("TitleDesc", "Protecting academic integrity with cutting-edge technology.");
            return View(examDetails);
        }

        [HttpPost]
        public async Task<IActionResult> MarkResult([FromBody] ExamDetailsForTeacher exam)
        {
            UserId = Int32.Parse(HttpContext.Request.Cookies["UserId"]);
            var subjectDetails = _dbContext.ExamModel.Where(e => e.Id == exam.ExamId).FirstOrDefault(); 
            var result = new StudentResult
            {
                StudentId = exam.StudentId,
                ExamId = exam.ExamId,
                SubjectId = subjectDetails.SubjectId,
                TeacherId = subjectDetails.TeacherId,
                Result = exam.Result
            };

            _dbContext.Add(result);
            await _dbContext.SaveChangesAsync();

            return Json(new { success = true, message = "Operation successfull." });
        }
    }
}
