﻿namespace WebApp_IntegrityGuard.DataModels
{
    public class ExamDetailsForTeacher
    {
        public int ExamId { get; set; }
        public int StudentId { get; set; }
        public string Name { get; set; }
        public string WarningColor { get; set; }
        public string WarningType { get; set; }
        public string Result { get; set; }
    }
}
