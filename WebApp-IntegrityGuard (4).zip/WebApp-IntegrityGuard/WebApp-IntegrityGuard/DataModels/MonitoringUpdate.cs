﻿namespace WebApp_IntegrityGuard.DataModels
{
    public class MonitoringUpdate
    {
        public string Message { get; set; }
        public DateTime Time { get; set; }
        public float TotalTime { get; set; }
        public string WarningType { get; set; }
        public int StudentId { get; set; }
        public int ExamId { get; set; }
    }
}
