﻿using WebApp_IntegrityGuard.Models;

namespace WebApp_IntegrityGuard.DataModels
{
    public class StudentPageData
    {
        public StudentPageData()
        {
            Exam = new List<ExamModel>();
        }
        public List<ExamModel> Exam { get; set; }
    }
}
