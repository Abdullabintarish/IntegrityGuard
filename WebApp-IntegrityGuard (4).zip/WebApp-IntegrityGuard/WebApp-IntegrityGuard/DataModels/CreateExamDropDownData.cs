﻿using WebApp_IntegrityGuard.Models;

namespace WebApp_IntegrityGuard.DataModels
{
    public class CreateExamDropDownData
    {
        public CreateExamDropDownData() {
            Subject = new List<Subject>();
            Invigilator = new List<Invigilator>();
            Exams = new List<ExamModel>();
        }
        public List<Subject> Subject { get; set; }
        public List<Invigilator> Invigilator { get; set; }
        public List<ExamModel> Exams { get; set; }
    }
}
