﻿using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.ComponentModel.DataAnnotations;
using System.Data;

namespace WebApp_IntegrityGuard.DataModels
{
    public class AddExamModel
    {
        public AddExamModel() {
            Date = DateTime.Now;
        }
        [Required(ErrorMessage = "Please select a subject.")]
        public string SubjectId { get; set; }
        [Required(ErrorMessage = "Please select an invigilator.")]
        public string InvigilatorId { get; set; }
        [Required]
        [DataType(DataType.Date)]
        [Display(Name = "Date")]
        [FutureDate(ErrorMessage = "Date must be in the future.")]
        public DateTime Date { get; set; }
        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "Start Time")]
        public DateTime StartTime { get; set; }
        [Required]
        [DataType(DataType.Time)]
        [Display(Name = "End Time")]
        [EndTime(OtherField = "StartTime", ErrorMessage = "End time must be later than start time.")]
        public DateTime EndTime { get; set; }
        [Required]
        public string TeacherId { get; set; }

    }
    public class FutureDateAttribute : ValidationAttribute
    {
        public override bool IsValid(object value)
        {
            DateTime d = Convert.ToDateTime(value);
            return d.Date >= DateTime.Now.Date;
        }
    }

    public class EndTimeAttribute : ValidationAttribute, IClientModelValidator
    {
        public string OtherField { get; set; }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            var otherProperty = validationContext.ObjectInstance.GetType().GetProperty(OtherField);
            var otherValue = otherProperty.GetValue(validationContext.ObjectInstance, null);
            var thisDate = (DateTime)value;
            var otherDate = (DateTime)otherValue;

            if (thisDate <= otherDate)
            {
                return new ValidationResult(ErrorMessage);
            }

            return ValidationResult.Success;
        }

        public void AddValidation(ClientModelValidationContext context)
        {
            context.Attributes.Add("data-val-endtime", ErrorMessage);
            context.Attributes.Add("data-val-endtime-other", OtherField);
        }
    }
}
