﻿using Microsoft.EntityFrameworkCore;
using WebApp_IntegrityGuard.Models;

namespace WebApp_IntegrityGuard.IntegrityGuard
{
    public class IntegrityGuardContext : DbContext
    {
        public IntegrityGuardContext(DbContextOptions<IntegrityGuardContext> options)
            : base(options)
        {
        }
        public DbSet<UserModel> Users { get; set; }
        public DbSet<Student> Student { get; set; }
        public DbSet<ExamModel> ExamModel { get; set; }
        public DbSet<ExamStatusModel> ExamStatusModel { get; set; }
        public DbSet<Subject> Subject { get; set; }
        public DbSet<Teacher> Teacher { get; set; }
        public DbSet<Enrollment> Enrollment { get; set; }
        public DbSet<Invigilator> Invigilator { get; set; }
        public DbSet<StudentResult> Result { get; set; }
    }
}