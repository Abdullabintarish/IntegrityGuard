﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApp_IntegrityGuard.Migrations
{
    /// <inheritdoc />
    public partial class DBStructureChange2 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
