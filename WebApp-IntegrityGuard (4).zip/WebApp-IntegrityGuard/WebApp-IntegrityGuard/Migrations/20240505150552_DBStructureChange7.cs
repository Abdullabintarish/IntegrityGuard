﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace WebApp_IntegrityGuard.Migrations
{
    /// <inheritdoc />
    public partial class DBStructureChange7 : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.AddColumn<string>(
                name: "WarningColor",
                table: "ExamStatusModel",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "WarningColor",
                table: "ExamStatusModel");
        }
    }
}
