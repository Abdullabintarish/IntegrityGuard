﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace WebApp_IntegrityGuard.Models
{
    public class Invigilator
    {
        [Key]
        public int InvigilatorId { get; set; }
        [ForeignKey("UserModel")]
        public int UserId { get; set; }
        public UserModel User { get; set; }
        public string Name { get; set; }
        public string Email { get; set; }
    }
}
