﻿namespace WebApp_IntegrityGuard.Models
{
    public class ExamStatusModel
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int ExamId { get; set; }
        public string Message { get; set; }
        public DateTime Time { get; set; }
        public float TotalTime { get; set; }
        public string WarningType { get; set; }
        public string WarningColor { get; set; }
    }
}
